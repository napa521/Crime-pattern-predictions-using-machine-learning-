# Crime_Detection
facial detection and weapon detection using ml
